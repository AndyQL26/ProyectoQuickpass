/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Fabia
 */
public class Quickpass {
    private String filial;
    private String codigo; 
    private String placa;
    private boolean estado; 

    public Quickpass(String filial, String codigo, String placa) {
        this.filial = filial;
        this.codigo = codigo;
        this.placa = placa;
        this.estado = true; 
    }

   
    public String getFilial() {
        return filial;
    }

    public String getCodigo() {
        return codigo;
    }

    public String getPlaca() {
        return placa;
    }

    public boolean isEstado() {
        return estado;
    }

    public void inactivar() {
        this.estado = false;
    }

    public void activar() {
        this.estado = true;
    }
}